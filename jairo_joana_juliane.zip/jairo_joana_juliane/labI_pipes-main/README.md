# labI_pipes
Repositório para a implementação do lab I da disciplina de Sistemas Operacionais
O programa espera uma entrada X do usuário, sendo X um valor inteiro entre 1-5.
Para executar, basta rodar make run
